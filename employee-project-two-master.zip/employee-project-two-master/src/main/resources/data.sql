INSERT INTO employee(id,name,designation,salary,age) values(101,'Shubhuu','manager',120000,24);
INSERT INTO employee(id,name,designation,salary,age) values(102,'Gauri','CEO',1200000,22);
INSERT INTO employee(id,name,designation,salary,age) values(103,'Poooogi','Developer',1200000,28);
INSERT INTO employee(id,name,designation,salary,age) values(104,'Ammmmuuuuuu','IAS',3600000,24);

INSERT INTO employee(id,name,designation,salary,age) values(105,'Shubhuu','manager',400,24);
INSERT INTO employee(id,name,designation,salary,age) values(106,'Gauri','CEO',410,99);
INSERT INTO employee(id,name,designation,salary,age) values(107,'Poooogi','Developer',420,182);
INSERT INTO employee(id,name,designation,salary,age) values(108,'Ammmmuuuuuu','IAS',430,69);