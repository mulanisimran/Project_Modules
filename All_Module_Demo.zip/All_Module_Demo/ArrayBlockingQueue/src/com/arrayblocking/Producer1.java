package com.arrayblocking;

import java.util.concurrent.BlockingQueue;

public class Producer1 implements Runnable {

	
	int questionNo;
	private BlockingQueue<Integer> questionQueue;




	public Producer1(BlockingQueue<Integer> questionQueue)
	{
	this.questionQueue = questionQueue;
	
	}
	
	
	
	
	@Override
	public void run() {
		
		while(true) {
		try {
			synchronized(this) {
				int nextQuestion = questionNo++;
				System.out.println("Got New Question: "+nextQuestion);
				questionQueue.put(nextQuestion);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		}
	}
	

	
//	private synchronized int getNextQuestion() {
//		int nextQuestion = questionNo++;
//		System.out.println("Got New Question: "+nextQuestion);
//		
//	}
}
