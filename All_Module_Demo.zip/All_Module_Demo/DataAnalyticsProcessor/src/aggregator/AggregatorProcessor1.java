package aggregator;

import java.io.IOException;

//import com.sun.tools.javac.util.List;
import java.util.List;

//import com.sun.tools.javac.util.List;

import fileprocessors.StockFileReader1;

public class AggregatorProcessor1<T extends Aggregator1>{
	
	T aggregator;
	String file;
	public AggregatorProcessor1(T aggregator, String file) {
		super();
		this.aggregator = aggregator;
		this.file = file;
	}
	
	public double runAggregator(int colIdx) throws IOException {
		StockFileReader1 fileReader = new StockFileReader1(file);
		List <String> lines = fileReader.readFileData();
		colIdx--;
		
		for (String line : lines) {
			String [] numbers = line.split(",");
			Number value = Double.parseDouble(numbers[colIdx]);
			aggregator.add(value.doubleValue());
			
		}
		
		double number = aggregator.calculate();
		return number;
	}

	
		
		
	}
