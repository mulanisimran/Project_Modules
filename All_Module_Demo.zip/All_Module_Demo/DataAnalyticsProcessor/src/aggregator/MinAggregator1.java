package aggregator;



import java.util.List;

public class MinAggregator1 extends Aggregator1{

	@Override
	public double calculate() {
		double min = numbers.get(0);
		for(double number : numbers){
			if(number < min){
				min = number;
			}
		}
		return min;
	}

	@Override
	public List<Double> getValues() {
		return numbers;
	}

}


	