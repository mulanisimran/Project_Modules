package client;



import java.io.IOException;

import aggregator.AggregatorProcessor1;
import aggregator.MeanAggregator1;
import aggregator.MinAggregator1;

//import aggregator.AggregatorProcessor1;
//import aggregator.MinAggregator1;

public class AggregatorApp1 {

	public static void main(String[] args) throws IOException {
		
		
		
//	MeanAggregator1 agg = new MeanAggregator1();
//	AggregatorProcessor1 <MeanAggregator1> aggProcessor = new AggregatorProcessor1 <MeanAggregator1>(agg,"table.csv");
//	double value = aggProcessor .runAggregator(3);
//	System.out.println(value);
//	
	
		
		/**
			You'll need to uncomment the below code. You'll notice it does not compile!
			(agg
			There are 2 objectives in this assignment.
			
			1).  Make sure the code compiles correctly after you uncomment it below.
			2).  Make sure it runs as explained in the assignment video!
			
			-->> YOUR WORK SHOULD BE DONE IN THE AggregatorProcessor CLASS. 
		**/

	MinAggregator1 agg = new MinAggregator1();
		AggregatorProcessor1<MinAggregator1> aggsProcessor = new AggregatorProcessor1<MinAggregator1>(agg, "table.csv");
		double value = aggsProcessor.runAggregator(1);
		System.out.println(value);
	

	}

}
