import java.util.ArrayList;

public class Collection1 {

	public static void main(String[] args) {
		ArrayList words = new ArrayList();
		words.add("Hello");//Add hello 
		words.add("Bye");
		words.add(50);
		words.add(10);
		words.add(80);
		
		words.remove(0);//Remove 0th slot of array
		
		//String item1 =(String)words.get(0);
		//Object item2 = words.get(1);
		int item1 = (int) words.get(2);
		int item2 = (int) words.get(3);
		System.out.println(item1 + item2);
		
		
		
		
		//Again get 0th slot which u removed--here we do casting because
		//get method doesnt convert object into string and "Hello" is a object which we add
		//the method gonna be returned which is called by object thats why we cascating .
		//Object is a parent for every single data type
		//Everything which is put into words is going to be an Object
		
		//String item2 =(String)words.get(1);
		//Instead of casting we can make item as a Object also.
		
		
		
	}

}
