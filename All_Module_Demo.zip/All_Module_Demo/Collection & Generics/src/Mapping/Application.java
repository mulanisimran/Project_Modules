package Mapping;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
//import java.util.LinkedList;

public class Application {

	public static void main(String[] args) {
		LinkedHashMap <String,String> dictionary = new LinkedHashMap<String,String>();//display in order of insertion
		//HashMap <String,String> dictionary = new HashMap<String,String>();
		dictionary.put("Simran", "Hiiii ..How Are u??");
		dictionary.put("Akil", "I am Fine");
		dictionary.put("Sana", "I am 20 years old");
		dictionary.put("Mustakim", "I stay in Pune");
		dictionary.put("Zishan", "I like to play Cricket");
		
		//for-each lioop
		//for(String word : dictionary.keySet()) {
			//System.out.println(word);
			//System.out.println(dictionary.get(word));//It prints values..like I a Fine
		//}
		
		
		//It will print key and value also
		for( Map.Entry<String,String> entry : dictionary.entrySet()){
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
			
			
			
		}
		
	}
	

}
