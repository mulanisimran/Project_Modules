package Mapping;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapping {

	public static void main(String[] args) {
		
		
		//TreeMap sort the keys in their natural order like alphabatically order
		//It can have duplicate but print new recent  value 
		TreeMap <String,String> dictionary = new TreeMap<String,String>();
		dictionary.put("Simran", "Hiiii ..How Are u??");
		dictionary.put("Akil", "I am Fine");
		dictionary.put("Sana", "I am 20 years old");
		dictionary.put("Mustakim", "I stay in Pune");
		dictionary.put("Zishan", "I like to play Cricket");
		
		//for-each loop
		//for(String word : dictionary.keySet()) {
			//System.out.println(word);
			//System.out.println(dictionary.get(word));//It prints values..like I a Fine
		//}
		
		
		//It will print key and value also
		for( Map.Entry<String,String> entry : dictionary.entrySet()){
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
			

		}
	}
}


