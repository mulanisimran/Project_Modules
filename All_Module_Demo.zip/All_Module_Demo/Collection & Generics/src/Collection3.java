import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Collection3 {

	public static void main(String[] args) {
		//ArrayList<String> animals = new ArrayList<String>();
		List<String> animals = new ArrayList<String>();
		animals.add("Lion");
		animals.add("Cat");
		animals.add("Dog");
		animals.add("Monkey");
		
//		for(int i=0 ; i < animals.size(); i++) {
//			System.out.println(animals.get(i));
//		}
//		
//		
//		for( String value : animals) {	//for each loop
//			System.out.println(value);
//		}
		
		
		//ArrayList<Vehicle> vehicles = new ArrayList<Vehicle00);//1000 is size of array
		List<Vehicle3> vehicles = new LinkedList<Vehicle3>();
		//We can use this one also instead of arraylist--List is an Interface
		Vehicle3 vehicle2 = new Vehicle3("Toyota","Camery",14000,false);//create instance and assign variable
		vehicles.add(vehicle2);
		vehicles.add(new Vehicle3 ("Honda","accord",16000, false));
		vehicles.add(new Vehicle3 ("Mahindra","Cavin",78000, true));
		vehicles.add(new Vehicle3 ("Jeep","Wrangler",92000, false));
		
		//for(Vehicle car : vehicles) {
			//System.out.println(car);//It prints output as Hashcode--instead of printElements statement use
		
//			System.out.println(car.getMake());//It will give data which we provide in object vehicle
//			System.out.println(car.getModel());
//			System.out.println(car.getPrice());
		
		
		//}
		
		printElements(vehicles);
		printElements(animals);
		
	}
	
	
	
	
public static void printElements(List someList) {
	for(int i=0 ; i < someList.size(); i++) {
		System.out.println(someList.get(i));
	}
	
}
}
		

	

	
