import java.util.ArrayList;
import java.util.LinkedList;

public class Collection2 {

	public static void main(String[] args) {
		ArrayList<String> words = new ArrayList<String>();
		words.add("Hello");//Add hello 
		words.add("Bye");
		words.add("50");
		words.add("10");
		words.add("80");
		
		words.remove(0);//Remove 0th slot of array
		
		//String item1 =(String)words.get(0);
		//Object item2 = words.get(1);
		String item1 = (String) words.get(1);
		System.out.println(item1);
	
		
		LinkedList<Integer> numbers = new LinkedList<Integer>();
		numbers.add(100);
		numbers.add(200);
		numbers.add(300);
		numbers.add(400);
		numbers.add(500);
		numbers.remove(4);
		
		for(int number : numbers) {
			System.out.println(number);
		}
		//We cannot use primitive data types like int 
		//needs only reference..Obnly complex datatypes are in angular brackets--int doesnt have class
		//Cant use primitive datatypes coz they are keywords--use wrapper class(Integer,Double,Float)
		
	
	
	}
}
		