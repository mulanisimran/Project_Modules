import java.util.Objects;

public class Animal4 {

	String name;
	int age;
	
	//Source->Generate constructor using fields
	public Animal4(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	//Source-> Generate to-string method
	@Override
	public String toString() {
		return "Animal4 [name=" + name + ", age=" + age + "]";
	}
	
	
	
	// Source-> Generate Hashcode and equals--
	@Override
	public int hashCode() {
		return Objects.hash(age, name);//It displays hascode value same
	}

	//It makes Comparison True
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Animal4 other = (Animal4) obj;
		return age == other.age && Objects.equals(name, other.name);
	}
	
	
	
}
