
public class Employee5 implements Comparable<Employee5> {
		
		String name;
		int salary;
		String department;
		public Employee5(String name, int salary, String department) {
			super();
			this.name = name;
			this.salary = salary;
			this.department = department;
		}
		@Override
		public int compareTo(Employee5 o) {
			if(this.salary < o.salary) {
				return -1;
						
			}else if (this.salary > o.salary) {
				return 1;
			}
				
			
			return 0;
		}
		
		
	 
	

	

}
