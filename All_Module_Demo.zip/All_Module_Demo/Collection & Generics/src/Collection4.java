import java.util.HashSet;
import java.util.LinkedHashSet;

public class Collection4 {

	public static void main(String[] args) {
		
		//LinkedHashSet<Integer> values = new LinkedHashSet<Integer>();//In order manner--duplicate not allowed
		HashSet<Animal4> animals = new HashSet<Animal4>();//Set doesn't contain duplicate values
		
		Animal4 animal1 = new Animal4 ("Dog",12);
		Animal4 animal2 = new Animal4 ("Cat",34);
		Animal4 animal3 = new Animal4 ("Monkey",40);
		Animal4 animal4 = new Animal4 ("Kangaroo",23);
		Animal4 animal5 = new Animal4 ("Bird",45);
		Animal4 animal6 = new Animal4 ("Bird",45);
		
		
		animals.add(animal1);
		animals.add(animal2);
		animals.add(animal3);
		animals.add(animal4);
		animals.add(animal5);
		animals.add(animal6);
		
		
		System.out.println(animal5 .equals(animal6));//It not consider both of this values are equal

		//System.out.println(animal5.hashCode());
		//System.out.println(animal6.hashCode());//It doesn't display repeated value like Bird
		
		
		
//		values.add(10);
//		values.add(47);
//		values.add(67);
//		values.add(34);
//		values.add(78);
//		values.add(47);
	
		
		for(Animal4 value : animals) {
			System.out.println(value);//Because we use equals method
		}
		
		

	}

}
