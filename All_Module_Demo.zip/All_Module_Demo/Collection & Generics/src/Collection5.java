import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Collection5 {

	public static void main(String[] args) {
		
//		ArrayList<Integer> list1 = new ArrayList<Integer>();
//		list1.add(10);
//		list1.add(20);
//		list1.add(30);
//		list1.add(40);
//		list1.add(50);
		
		//Convert hashset into list
		HashSet<Integer> hashSet = new HashSet<Integer>();
		hashSet.add(10);//6th value added at end
		hashSet.add(67);
		hashSet.add(43);
		hashSet.add(20);
		
		List<Integer> li = new ArrayList<Integer>(hashSet);//Converting
		
		
		
		
		
		
		
		
		
		
		
		ArrayList<Integer> newlist = new ArrayList<Integer>();
		newlist.add(10);//6th value added at end
		newlist.add(67);
		newlist.add(43);
		newlist.add(20);
		
		
		
		//list1.addAll(newlist);
		//list1.removeAll(newlist);//newlist merge into list1--newlist contains the data removed form original list1
		//System.out.println(list1);
		//list1.clear();//It gives empty array
		
		//boolean hasValue =list1.contains();//To check particular item in list
		
		//boolean hasValue =list1.isEmpty();//It checks list is empty or not
		
		//boolean hasValue =list1.retainAll(newlist);//It removes eveything except for the value you like to retain
		//Delete everything from list1 which is not in newlist
		
		//list1.removeAll(newlist);//If we add lots of 10 above then none of 10 will be added in list
		//newlist contains the data removed form original list1
	}

}
