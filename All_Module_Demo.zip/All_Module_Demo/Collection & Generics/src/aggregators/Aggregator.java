package aggregators;

public class Aggregator {

}
