import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class Collec5HashSet {

	public static void main(String[] args) {
		//Convert hashset into list
//				HashSet<Integer> hashSet = new HashSet<Integer>();
//				hashSet.add(10);//6th value added at end
//				hashSet.add(67);
//				hashSet.add(43);
//				hashSet.add(20);
//				hashSet.add(10);
//				hashSet.add(42);
//				hashSet.add(56);
				
				
				HashSet<Employee5> hashSet = new HashSet <Employee5>();
				hashSet.add(new Employee5 ("Mike",3500 ,"Accounting"));
				hashSet.add(new Employee5 ("Simran",4000 ,"It"));
				hashSet.add(new Employee5 ("Zishan",1200 ,"Admin"));
				hashSet.add(new Employee5 ("Akil",8500 ,"Maintainance"));
				
				
						
				
				
				
				
			//Convert hashset into array list
				ArrayList<Employee5> myList = new ArrayList<Employee5>(hashSet);	
			//To sort data
				Collections.sort(myList);
				System.out.println(myList);
				//Collections.sort(hashSet);
		

	}

}
