package com.simran.learning.jpa.jpainwebservices.service;

import org.springframework.data.jpa.repository.JpaRepository;


import com.simran.learning.jpa.jpainwebservices.entity.User;

public interface UserRepository extends JpaRepository<User, Long>{

}
