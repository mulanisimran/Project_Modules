package com.simran.learning.jpa.jpainwebservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaInWebServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaInWebServicesApplication.class, args);
	}

}
