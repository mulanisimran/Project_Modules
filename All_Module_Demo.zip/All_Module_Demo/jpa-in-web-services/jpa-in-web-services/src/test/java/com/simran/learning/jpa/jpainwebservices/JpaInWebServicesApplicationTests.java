package com.simran.learning.jpa.jpainwebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaInWebServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
