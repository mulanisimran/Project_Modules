package com.ThreadPools;

public class MessageProcessor implements Runnable {

	private int  message;
	
	public MessageProcessor(int message) {
		this.message = message;
		
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()   + "[RECEIVED ] Message = " +message);
		respondToMessage();//make thread sleep to simulte soing the work
		System.out.println(Thread.currentThread().getName()   + "[DONE ] Processing  Message = " +message);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			
			System.out.println("Unable to run message"  +message);
			//e.printStackTrace();
		}
		
	}

	private void respondToMessage() {
		// TODO Auto-generated method stub
		
	}
}
