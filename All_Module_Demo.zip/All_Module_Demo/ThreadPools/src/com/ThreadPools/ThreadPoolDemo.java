package com.ThreadPools;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ThreadPoolDemo {

	public static void main(String[] args) {
		
		ExecutorService executor = Executors.newFixedThreadPool(2); //recycle Threads
		
		
		Runnable processor1  = new MessageProcessor(2);
		executor.execute(processor1);
		
		Runnable processor2  = new MessageProcessor(3);
		executor.execute(processor2);

		Runnable processor3  = new MessageProcessor(4);
		executor.execute(processor3);
		
		executor.shutdown(); //Rejects any new tasks from being submitted--shutdown the service--to stop this red light
		//If we comment these shutodown it will never terminted/stop..Output will give continuously..never stop the process
		
		//executor.shutdownNow(); //stop execution immediately--Terminate the executor the service immediately
		
		
		try {
			executor.awaitTermination(2, TimeUnit.SECONDS); //wait 10 sec before moving to next line--this is Enumeration
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
//		while(!executor.isTerminated()) {
//			//Submited all tasks displays at the end
//		}
		
		
		System.out.println("Submitted All Tasks...!!!"); //display at the begining

	}

}
