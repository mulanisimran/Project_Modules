package com.simran.springboot.SpringbootDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDemoInSpringFrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
