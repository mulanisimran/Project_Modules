package com.simran.springboot.SpringbootDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDemoInSpringFrameworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDemoInSpringFrameworkApplication.class, args);
	}

}








