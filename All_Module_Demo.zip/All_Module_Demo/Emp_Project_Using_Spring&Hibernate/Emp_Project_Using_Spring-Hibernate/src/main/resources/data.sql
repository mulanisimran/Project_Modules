insert into Emp99(id,name,salary, designation)
values(20001,'Simran',40001,'Software Engineer');
insert into Emp99(id,name,salary ,designation)
values(20002,'Sana',40002,'Technical Support');
insert into Emp99(id,name,salary, designation)
values(20003,'Mustakim',40003,'Manager');
insert into Emp99(id,name,salary, designation)
values(20004,'Zishan',40004,'Admin');
insert into Emp99(id,name,salary, designation)
values(20005,'Akil',40005,'Clerk');
