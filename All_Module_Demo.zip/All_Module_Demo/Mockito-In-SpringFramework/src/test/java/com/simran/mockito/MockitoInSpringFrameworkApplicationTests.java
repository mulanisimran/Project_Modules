package com.simran.mockito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockitoInSpringFrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
