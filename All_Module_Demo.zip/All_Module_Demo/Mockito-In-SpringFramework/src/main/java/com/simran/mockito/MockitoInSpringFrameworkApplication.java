package com.simran.mockito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockitoInSpringFrameworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockitoInSpringFrameworkApplication.class, args);
	}

}
