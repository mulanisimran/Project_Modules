package com.simran.mockito;

public interface DataService {
	int[] retrieveAllData();
}
