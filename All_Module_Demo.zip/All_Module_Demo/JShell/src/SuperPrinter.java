
public class SuperPrinter {

	public static void main(String[] args) {
		
		
		
	}
	public void print() {
		System.out.println("Some Random Text");
	}
	
}


