package client;

public class Accountant extends Employee {	//Accountant is a child of Employee
	
	//@Override	
	public void work() {
			System.out.println("Accountance Working");
		}
}
