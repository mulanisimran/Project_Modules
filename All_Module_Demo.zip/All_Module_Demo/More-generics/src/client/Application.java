package client;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

//import java.util.ArrayList;

public class Application {

	public static void main(String[] args) {
		
		Container<Integer,String> container = new Container<>(12,"Hello");
		int val1 = container.getItem1();
		String val2 = container.getItem2();//Container is generic class
		
		Set<String> mySet1 = new HashSet<String>();
		mySet1.add("First");
		mySet1.add("Second");
		mySet1.add("Third");
		mySet1.add("Fourth");
		
		
		Set<String> mySet2 = new HashSet<String>();
		mySet1.add("First");
		mySet1.add("Second");
		mySet1.add("Third");
		mySet1.add("Whatever");
		
		
		Set<String> resultSet = union(mySet1, mySet2);
		Iterator<String> itr = resultSet.iterator();
		
		while(itr.hasNext()) {
			String var = itr.next();
			System.out.println(var);
			//System.out.println(itr.next());
		}
		
		
	
	}
	
	public static <E> Set<E> union(Set<E> set1 , Set<E> set2) {//E,V,O,G are defined parameters only provide next to static<E>..If we try to put 
		//any string like Hello in <E> it is not acceptable
		//Typed parameter<i1,i2> defined in main method with union
		Set<E> result = new HashSet<E>(set1);
		result.addAll(set2);
		return result;
		
	}
}
		
		
		
		
		
		
		
		
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		ArrayList<String> mylist = new ArrayList<String>();
//		mylist.add("Simran");
//		mylist.add("100");
//		mylist.add("XYZ");
//		mylist.add("67");
//		//mylist.add(false);//Adding any datatype it means raw data
	
	
	//String myval = (String) mylist. get(0);
	//String myval2 = (String) mylist.get(1);
	


