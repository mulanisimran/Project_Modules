package client;

import java.util.ArrayList;
import java.util.List;



public class GenericWildcard {

	public static void main(String[] args) {
		Object myObject = new Object();//grand
		String myVar = "Hello";
		myObject = myVar;//Valur of myVar given to myObject
		
		Employee emp = new Employee();
		Accountant acc = new Accountant();
		emp=acc;//Polyporphism
		
		ArrayList <Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee());
		ArrayList <Accountant> accountants = new ArrayList<Accountant>();
		//If we use generics ,we cannot assign employees=accountants
		accountants.add(new Accountant());//we cannot do like that application is not applicable for the argument
		
		//employees = accountants;
		
		
		//To allow assigning in Generics we use wilcard (?)
		ArrayList<?> employees2 = new ArrayList<>();
		ArrayList <Accountant> accountants2 = new ArrayList<>();
		employees2 = accountants2;
		
		//Upper Bound
		ArrayList<? extends Employee> emp3 = new ArrayList<>();//Object is not allow here beacause it is not subclass ,it is parent of Employee
		ArrayList <Employee> accountants3 = new ArrayList<>();
		emp3 = accountants3;

		
		//This prevents subclasses making into it-----Lower Bound
		ArrayList<? super Employee> emp4 = new ArrayList<>();
		//not run because of Employee has only one parent i.e Object--for assigning use Object as type
		ArrayList <Object> accountants4 = new ArrayList<>();
		emp4 = accountants4;
		
		
		//we can not pass accountants for this we need to extend Employee in main method
		makeEmployeeWork(accountants);
	}
	
	public static void makeEmployeeWork(List< ? extends Employee> employees) {
		//Downcasting
		for(Accountant emp : (ArrayList<Accountant>) employees) {
			emp.work();
		}
		
	}
		
		
		
		
		
		

	

}
