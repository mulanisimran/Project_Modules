
public class Thread1 {

	public static void main(String[] args) {
		
		System.out.println("Starting Thread 1");
		Thread t1 = new Thread ( new Runnable() { 
		// Instance of class Task--Single threaded program
		//set the name of thread
		//Task taskRunner = new Task("Thread-A");
		//Thread t1 = new Thread(taskRunner); //To avoid run() method
		//Thread t1 = new Thread(new Task("Thread-A"));
		
		@Override
		public void run() {
			
			//Thread.currentThread().setName(this.name);
			
			for(int i=0 ; i<1000 ; i++) {
				
				
				//It will print number and therir corresponding thread e.g.- Number:23 - Thread-0 or 1
				//Thread 0 represents first thread and Thread 1 represents second thread
				System.out.println("Number:" +i+" - " + Thread.currentThread().getName());

				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		});
		
		t1.start();
		 //Invoke a start() method to begin execution--It invokes run() method in seprate thread
		
		
		
		//Here we execute main thread
		System.out.println("Starting Thread 2"); 
		//Task taskRunner2 = new Task("Thread-B");
		//Thread t2 = new Thread(taskRunner2); //To avoid run() method
		//Thread t2 = new Thread(new Task("Thread-B"));
		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				
				//Thread.currentThread().setName(this.name);
				
				for(int i=0 ; i<1000 ; i++) {
					
					
					//It will print number and therir corresponding thread e.g.- Number:23 - Thread-0 or 1
					//Thread 0 represents first thread and Thread 1 represents second thread
					System.out.println("Number:" +i+" - " + Thread.currentThread().getName());
	
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});
		t2.start();
		//taskRunner2.run();
	
		
	}



class Task implements Runnable {
//class Task extends Thread{
	
	String name;
	
	public Task(String name) {
		this.name = name;
	}
	
	//Single threaded program--only main gets run--
	public void run() {
		Thread.currentThread().setName(this.name);
		
		for(int i=0 ; i<1000 ; i++) {
			
			
			//It will print number and therir corresponding thread e.g.- Number:23 - Thread-0 or 1
			//Thread 0 represents first thread and Thread 1 represents second thread
			System.out.println("Number:" +i+" - " + Thread.currentThread().getName());
			
			
			
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
}

//In Single Thread , We can move to next thread when previous is complete
//In Multi thread, Can not wait to complete previous thread..it will move to next thread
//When taskRunner starts it was kicked off ..java interpreter doesnot wait here..he moved on better things i. e next line
//We cannot start start() method again ..it will throw exception i.e.  illlegalThreadStateException
//To resolve this exception , we need to  create instance of task again in main method
//Because of this two start() methods output will be printing like repeating values are there from 0 to 999
//We can sleep() thread for 10 miliseconds
// setName() use to set the name of thread---by default name is Thread-To set name give propery in Task class loke String name
//Class Task implements Runnable interface but not able to execute start() method because class Task is not a Thread 
//.Now it is Runnable interface----Instead of start() we use run() method

//run() method is not gonna make multithreading program---regular object orientation
//We need a run class on particular thread thats why define thread------Thread T1 = new Thread();