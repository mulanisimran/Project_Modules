package ThreadingInventoryManager;

public class Application {

	public static void main(String[] args) throws InterruptedException {
		InventoryManager manager = new InventoryManager();
		
		
		Thread inventoryTask = new Thread(new Runnable() {
			

			@Override
			public void run() {
				manager.populateSoldProducts();
				
			}
			
		});
		
		
		
			Thread displayTask = new Thread(new Runnable() {
			

			@Override
			public void run() {
				manager.displaySoldProducts();
				
			}
			
		});
			
			//One class is reading and other is able to read at same time beacause of CopyOnWriteArrayList
			//Printing and adding at the same time
			inventoryTask.start();
			//inventoryTask.join();//It wait waits here until inventory i.e above line completed
			
			//loading data into that collection CopyOnWriteArrayList
			Thread.sleep(2000);
			
			displayTask.start();
		

	}

}
