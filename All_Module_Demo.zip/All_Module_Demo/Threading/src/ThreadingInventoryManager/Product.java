package ThreadingInventoryManager;

public class Product {
	int id;
	String name;
	
	
	//generate Constructor using fields
	public Product(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	//generate to-String method
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + "]";
	}





	public static void main(String[] args) {
		
	}

}
