package ThreadingInventoryManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CopyOnWriteArrayList;

public class InventoryManager {
	List<Product> soldProductList = new CopyOnWriteArrayList<Product>();
	List<Product> purchasedProduct = new ArrayList<Product>();
	
	Vector vector = new Vector();
	
	
	
	public void populateSoldProducts() {
		for(int i=0 ;i<1000 ;i++) {
			Product prod = new Product(i,"test_product_"  +i);  //Instantiate Product
			soldProductList.add(prod);
			System.out.println("ADDED  :"  +prod);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	
	public void displaySoldProducts() {			//This iterate over soldProductList
		for(Product product : soldProductList ) {
			System.out.println("PRINTING THE SOLD :"  +product);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
			
		}
		
	}

}
