
public class Thread2 {

	public static void main(String[] args) {
		
		Sequence sequence = new Sequence();        //Instance of sequence class
		
		Worker worker1 = new Worker(sequence);				//Create two worker threads operating on same object sequence
		worker1.start();
		
		Worker worker2 = new Worker(sequence);
		worker2.start();
		
		
		
		
		
		
		//for(int i=0 ; i< 100 ; i++) {
			//System.out.println(sequence.getNext());  //It will priint 1 to 100
	//}

}
}

class Worker extends Thread{
	Sequence sequence = null;						//Initializes to Null
	public Worker (Sequence sequence) {
		this.sequence = sequence;
		
	}
	
	
	//Override run() method
	public void run() {
		for(int i=0 ; i< 100 ; i++) {
			System.out.println(Thread.currentThread().getName()   +   "Got value:"   +   sequence.getNext());//Numnbers print all unique 
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	}
	}
}