
public class Sequence {

	
	private int value =0; 
	public  synchronized  int getNext() {			// getNext() return integer increment to the next value
		
		//synchronized(this){
			value++;					//member variable of class i.e initialize with private method--
			return value;				//return updated value--it will o/p as unique values
			
			
		}
		
		
	}



//This value is not safe because it shared to multiple threads--thats why we see repeated values in output
//value=value+1--3+1=4--need to read value is 3---return value is 4--control gives to 4--We can do it single thread not in multi thread

//How to make thread safe??-> Concept use which known as "Atomacity" that means we either wants to run the line or not

//To make this atomic there is a keywork called "Synchronized"--for synchrized we need to specify object "this"
//Noone allowed to enter in the synchronized block