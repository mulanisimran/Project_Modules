package producerconsumer;

 	import java.util.List;

	public class Consumer implements Runnable{
		
		
		List<Integer> questionlist = null;
		                 
		 
		
		
		Object myObject = new Object();
		
		public Consumer (List<Integer> questionlist) {
			this.questionlist = questionlist;
			
		}
		
		
		//To read questions
		public void answerQuestion() throws InterruptedException
		{
			
			synchronized(questionlist) {
				
				while(questionlist.isEmpty()) {
					System.out.println("No Question to anser..Waiting for producer to get questions ");
					questionlist.wait();		//Qestionlist is empty
					
				}
				
			}
		
			
			synchronized(questionlist) {
				Thread.sleep(100);
				System.out.println("Answered Question  :"  +questionlist.remove(0));
				
				//Notify question has been assed in questionlist--notify that threads they are waiting for the notification wake up
				questionlist.notify();
				//questionlist.notifyAll();
			}
		}
		
		

		@Override
		public void run() {
			while(true) {
				try {
					//It continuously produce questions
					answerQuestion();				
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}	
			}
			
		

	}


	//questionlist is a shared resource--for shared resources we use "synchronized" keyword
	//Notify question has been assed in questionlist--notify that threads they are waiting for the notification wake up
	//control on questionlist object
	//If we want to give control on another block ,we use wait()
	 //wait() and notify()  only called inside the synchronized block
	//remove() just not remove lines it returns the value also able to print removable value
	