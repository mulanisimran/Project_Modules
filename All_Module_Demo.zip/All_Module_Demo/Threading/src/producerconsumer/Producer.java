package producerconsumer;

import java.util.List;

public class Producer implements Runnable {
	
	
	List<Integer> questionlist = null;
	final int LIMIT = 5 ;                   //Set limit for questions i.e 5 question
	private int questionNo ;
	
	
	Object myObject = new Object();
	
	public Producer (List<Integer> questionlist) {
		this.questionlist = questionlist;
		
	}
	
	
	//To read questions
	public void readQuestion(int questionNo) throws InterruptedException
	{
		
		synchronized(questionlist) {
			
			while(questionlist.size() == LIMIT) {
				System.out.println("Questions have piled up!!!!.....Wait for answers");
				questionlist.wait();
				
			}
			
		}
	
		
		synchronized(questionlist) {
			System.out.println("New Question  :"  +questionNo);
			questionlist.add(questionNo);
			Thread.sleep(1000);
			
			//Notify question has been assed in questionlist--notify that threads they are waiting for the notification wake up
			questionlist.notify();
			//questionlist.notifyAll();
		}
	}
	
	

	@Override
	public void run() {
		while(true) {
			try {
				//It continuously produce questions
				readQuestion(questionNo++);				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}	
		}
		
	

}


//questionlist is a shared resource--for shared resources we use "synchronized" keyword
//Notify question has been assed in questionlist--notify that threads they are waiting for the notification wake up
//control on questionlist object
//If we want to give control on another block ,we use wait()
 //wait() and notify()  only called inside the synchronized block