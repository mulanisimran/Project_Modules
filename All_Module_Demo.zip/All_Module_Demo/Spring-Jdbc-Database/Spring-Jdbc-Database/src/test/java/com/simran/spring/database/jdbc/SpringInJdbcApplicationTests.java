package com.simran.spring.database.jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
