package com.simran.spring.database.jdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringInJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringInJdbcApplication.class, args);
	}

}
