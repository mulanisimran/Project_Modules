import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

abstract class Employee{

         String name ;
         int age;
         String designation;
         double salary;
         int count;

         abstract void raiseSalary();

    Employee(){
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter the name : ");
            name = sc.nextLine();
            System.out.print("Enter the age : ");
            age = sc.nextInt();

        }


        void display(){
            System.out.println("****************");
            for (int i = 0; i <1; i++){
                System.out.println("NAME :" + name);
                System.out.println("AGE : " + age);
                System.out.println("DESIGNATION : " + designation);
                System.out.println("SALARY : " + salary);
            }
        }
}

class Manager extends Employee{

    @Override
    void raiseSalary() {
        double temp = salary * 0.3;
        salary = salary + temp;
    }

    Manager() {
        designation = "Manager";
        salary = 36000;
        count++;
    }
}

class Clerk extends Employee{

    @Override
    void raiseSalary() {
        double temp = salary * 0.05;
        salary = salary + temp;
    }

    Clerk() {
        designation = "Clerk";
        salary = 12000;
        count++;
    }
}

class Programmer extends Employee{

    @Override
    void raiseSalary() {
        double temp = salary * 0.2;
        salary = salary + temp;
    }

    Programmer() {
        designation = "Programmer";
        salary = 28000;
        count++;
    }
}

public class InformationData {
    public static void main(String[] args) {
            int choice1 = 0;
            int choice2 = 0;

        ArrayList<Object> arr = new ArrayList();


            Scanner sc = new Scanner(System.in);
            Clerk c;
            while(choice1 != 4){
                System.out.print("1.Create\n2.Display\n3.Rise Salary\n4.Exit\nEnter your choice : ");
                choice1 = sc.nextInt();
                switch (choice1){
                    case 1:
                           while(choice2 != 4){
                               System.out.print("1.Clerk\n2.Programmer\n3.Manager\n4.Exit\nEnter your choice : ");
                               choice2 = sc.nextInt();
                               switch (choice2){
                                   case 1:
                                       c = new Clerk();
                                       arr.add(c);
                                         break;
                                   case 2:
                                       Programmer p = new Programmer();
                                       arr.add(p);
                                         break;
                                   case 3:
                                       Manager m = new Manager();
                                       arr.add(m);
                                         break;
                                   case 4:
                                       System.out.println("Returning to main menu");
                                       choice2 = 4;
                                       break;
                                   default:
                                       System.out.println("Wrong choice, try again");
                               }
                           }
                           choice2 = 0;
                           break;
                    case 2 :
                        Iterator it = arr.iterator();
                        while(it.hasNext()){
                            Employee e = (Employee) it.next();
                            e.display();
                        }


                        break;
                    case 3:
                        System.out.println("Rising the salary");
                        Iterator ite = arr.iterator();

                        while(ite.hasNext()){
                            Employee e = (Employee) ite.next();
                            e.raiseSalary();
                        }

                        break;
                    case 4:
                          choice1 = 4;
                          break;
                    default:
                        System.out.println("Wrong choice, try again");


                }
            }
    }
}