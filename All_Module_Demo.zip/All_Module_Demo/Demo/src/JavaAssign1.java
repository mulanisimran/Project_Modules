import java.util.*;
import java.io.*;

public class JavaAssign1 {

	public static void main(String[] args) {
		Emp x[] = new Emp[10];
		for (int k=0;k<10;k++) {
			x[k] = new Emp();
			
		}

		int a=1,i=0;
		while(true)
		{
		
			System.out.println("\n***************************************\n"+"\n1.CREATE\n" + "2.DISPLAY\n" + "3.RiseSalary\n" + "4.EXIT");
			Scanner sc = new Scanner(System.in);
			System.out.println("ENTER YOUR CHOICE:");
			a = sc.nextInt();
			
			
			switch(a) {
			case 1:
				System.out.println("1.CLERK\n2.MANAGER\n3.DEVELOPER\n4.TESTER");
				Scanner sc1=new Scanner(System.in);
				int b = sc1.nextInt();
				x[i].Emp1(b);
				i++;
				break;
				
				
			case 2:
				for(int k=0 ; k < i; k++ ) {
					x[k].display();
				}
				break;
				
			case 3:
				System.out.println("RiseSalary");
				break;
				
			case 4:
				System.out.println("**********************************************");
				break;
				
				
			default:
				System.out.println("ENTER VALID YOUR CHOICE");
				break;
				}
				
			}
		
		
		}
	}

class Emp{
	String name;
	int age;
	int salary;
	int designation;
	
	public void Emp1(int b) {
		//designation = b;
		Scanner sc2=new Scanner(System.in);
		System.out.println("\nENTER THE  NAME:");
		name=sc2.nextLine();
		System.out.println("\nENTER THE AGE:");
		age=sc2.nextInt();
		System.out.println("\nENTER THE SALARY:");
		salary= sc2.nextInt();
		System.out.println("\nENTER THE DESIGNATION:");
		designation= sc2.nextInt();
	}
	
	public void display() {
		
		System.out.println("\nNAME:" +name+"\nAGE:"+age+"\nSALARY"+salary+"\nDESIGNATION"+designation );
		
		switch(designation)
		{
		case 1 :
			System.out.println("Designation: CLERK");
			break;
			
		case 2:
			System.out.println("Designation: MANAGER");
			break;
			
		case 3 :
			System.out.println("Designation: DEVEL2OPER");
			break;
			
		default:
			System.out.println("Enter valid Choice");
			break;
			
			
		}
		
		
	}
}


