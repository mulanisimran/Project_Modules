import com.simran.exception.FooRuntimeException;

public class MyFileUtils {
	public int subtract10fromlargerNumber(int number) throws FooRuntimeException
	{
		if(number < 10) {
			//throw new Exception("The number passes was smaller than 10");// Exception is a class and thats why instance is made with new keyword
			throw new FooRuntimeException("The number passes was smaller than 10");
			}
		
		return number-10;
	}
	
	
	
}