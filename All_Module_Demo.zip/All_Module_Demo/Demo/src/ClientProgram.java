
public class ClientProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 CommandLine cml=new CommandLine();
	     int result= cml.multiply(2, 3, 4);
	     System.out.println("Result of Multiplyer:");
	     System.out.println(result);

	}

}
