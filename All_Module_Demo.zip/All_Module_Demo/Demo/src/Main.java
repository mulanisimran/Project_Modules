import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

abstract class Employee{

         String name ;
         int age;
         String designation;
         double salary;
         static int count;

    Employee(){
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter the name : ");
            name = sc.nextLine();
            System.out.print("Enter the age : ");
            age = sc.nextInt();
           // System.out.print("Enter the designation :  ");
            //designation= sc.nextLine();
            //System.out.print("Enter the salary :  ");
            //salary= sc.nextInt();

        }


        public void display(){
            for (int i = 0; i <1; i++){
                System.out.println("**********************************************");
                System.out.println("\nNAME :" + name);
                System.out.println("\nAGE : " + age);
                System.out.println("\nDESIGNATION : " + designation);
                System.out.println("\nSALARY : " + salary);
                System.out.println("**********************************************");
            }
        }


}

class Manager extends Employee{
    Manager() {
        designation = "Manager";
        salary = 36000;
        count++;
    }
}

class Clerk extends Employee{

    Clerk() {
        designation = "Clerk";
        salary = 12000;
        count++;
    }
}

class Programmer extends Employee{

    Programmer() {
        designation = "Programmer";
        salary = 28000;
        count++;
    }
}

public class Main {
    public static void main(String[] args) {
            int choice1 = 0;
            int choice2 = 0;

        ArrayList<Object> arr = new ArrayList<Object>();


            Scanner sc = new Scanner(System.in);

            while(choice1 != 4){
		System.out.println("Enter your choice:");
                System.out.println("1.Create\n2.Display\n3.Rise Salary\n4.Exit");
                choice1 = sc.nextInt();
                switch (choice1){
                    case 1:
                           while(choice2 != 4){
                               System.out.println("1.Clerk\n2.Programmer\n3.Manager\n4.Exit");
                               choice2 = sc.nextInt();
                               switch (choice2){
                                   case 1:
                                       Clerk c = new Clerk();
                                       arr.add(c);
                                         break;
                                   case 2:
                                       Programmer p = new Programmer();
                                       arr.add(p);
                                         break;
                                   case 3:
                                       Manager m = new Manager();
                                       arr.add(m);
                                         break;
                                   case 4:
                                       System.out.println("Returning to main menu");
                                       choice2 = 4;
                                       break;
                                   default:
                                       System.out.println("Wrong choice, try again");
                               }
                           }
                           choice2 = 0;
                           break;
                    case 2 :
                        Iterator it = arr.iterator();

                        while(it.hasNext()){
                            Employee e = (Employee) it.next();
                            e.display();
                        }


                        break;
                    case 3:
                        System.out.println("Rising the salary");
                        break;
                    case 4:
                          choice1 = 4;
                          break;
                    default:
                        System.out.println("try again");


                }
            }
    }
}
