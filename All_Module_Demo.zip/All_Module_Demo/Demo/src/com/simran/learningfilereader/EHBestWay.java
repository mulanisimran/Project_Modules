package com.simran.learningfilereader;

import java.io.*;

public class EHBestWay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("myfile.txt");// if file name is wrong it will throw file not
		//found with NullPointerException
			
		BufferedReader bufferedReader = null;//we are not assigned object yet
		FileReader filereader = null;
		try(FileReader filereader1 = new FileReader(file);
				BufferedReader bufferedReader1 = new BufferedReader(filereader1);) {
			
//java-7 feature			
//Defining and Assigning in try block--Because of this we dont need to close this readers			
// Instead of Scanner we can use file--If define above filereader1 then not need to write here again
//reader--program crashed file because of wrong file name & it will never moved on
//bufferedReader statement
			
			
			

			String line = bufferedReader1.readLine();// It throws IOException - BuferedReader.class

			while (line != null) {
				System.out.println(line);
				line = bufferedReader.readLine();

			}

		} catch (FileNotFoundException e) {
			
			System.out.println("File Not Found");// This line throws IOException
			// e.printStackTrace();
		} catch (IOException e) {
			
			// e.printStackTrace();
			System.out.println("Problem reading the file" + file.getName());
		}

		
		}

	}


