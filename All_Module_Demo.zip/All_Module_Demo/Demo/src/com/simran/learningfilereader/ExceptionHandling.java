package com.simran.learningfilereader;

import java.io.*;

public class ExceptionHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("myfile.txt");// if file name is wrong it will throw file not
		//found with NullPointerException
			
		BufferedReader bufferedReader = null;//we are not assigned object yet
		FileReader filereader = null;
		try {
			
			filereader = new FileReader(file);// Instead of Scanner we can use file--If define above filereader then not need to write here again
			//reader--program crashed file becoz of wrong file name & it will never moved on
			//bufferedReader statement
			
			
			bufferedReader = new BufferedReader(filereader);//here we are assigned object
			

			String line = bufferedReader.readLine();// It throws IOException - BuferedReader.class

			while (line != null) {
				System.out.println(line);
				line = bufferedReader.readLine();

			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found");// This line throws IOException
			// e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("Problem reading the file" + file.getName());
		}

		finally {
			// Area to close the resources.Even if try block get executed,finally will
			// execute also.use to close bufferedReader--Finall block always runs

			try {
				if(bufferedReader != null) {  
//Better way to solve Null pointer exception problem by using if statement in finally- try block
				bufferedReader.close();
// close() also throws IOException ,NullPointerException because of wrong file name
				}					
				if(filereader != null) {
				filereader.close();
				}
				
			} catch (IOException e) {
				System.out.println("Unable to Close File" + file.getName());
				// e.printStackTrace();
				
				
			}//catch(NullPointerException ex) {
				//System.out.println("File was probably never Opened" +ex);
			//}
		}

	}

}
