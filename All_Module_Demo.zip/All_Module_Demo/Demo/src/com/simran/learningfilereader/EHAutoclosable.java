package com.simran.learningfilereader;

class MyClass implements AutoCloseable{

	@Override
	public void close() throws Exception {     //used to close Internet, database connectivity
		
		System.out.println("Closing!");
	}
	
	
}

public class EHAutoclosable {

	public static void main(String[] args) {
		
		try(MyClass var= new MyClass();){ // var object is resource
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
