package com.simran.exception;

public class FooRuntimeException extends Exception{
	public FooRuntimeException(String message) {
		super(message);
	}

}