
public class CommandLine {

	//public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int multiply(int arg1, int arg2 ,int arg3)
		    {
		        return arg1 * arg2 *arg3;
		    }
		    

	}


