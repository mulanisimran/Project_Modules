import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Application {

	public static void main(String[] args) throws Exception {
	

		System.out.println();
		
		
		// System.in();
//	for(int i=0;i<=3;i++) {
//	Scanner input =new Scanner(System.in);
//	System.out.println("Enter some Text:");
//	String enteredText = input.nextLine();
//	System.out.println("enteredText");
		
		
		try {
			File file = new File("myfile.txt");
			// Scanner input =new Scanner(file);
			Scanner input;
			input = new Scanner(file);

			while (input.hasNext()) {
				String line = input.nextLine();
				System.out.println(line);

			}
			input.close();
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
			// e.printStackTrace();

		}

		MyFileUtils myutil = new MyFileUtils();
		try {
			System.out.println(myutil.subtract10fromlargerNumber(50));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
