package com.Employee.info.usingJDBC;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

abstract class Employee{

    String name ;
    int age;
    String designation;
    double salary;
    int id;
    int count;
    ConnectionDB connectionDB = new ConnectionDB("root","root");

    abstract void raiseSalary() throws SQLException;

    Employee(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the id : ");
        id = sc.nextInt();
        System.out.print("Enter the name : ");
        name = sc.nextLine();
        System.out.print("Enter the age : ");
        age = sc.nextInt();
        System.out.print("Enter the designation : ");
        designation = sc.next();
        System.out.print("Enter the salary : ");
        salary = sc.nextInt();
       
    }

    void display() throws SQLException {
        connectionDB.display();
    }
}

final class Manager extends Employee{

    //@Override
    void raiseSalary() throws SQLException {
        salary = salary + 10000;
        connectionDB.update(salary);

    }

    Manager() {
        designation = "Manager";
        salary = 36000;
        count++;
    }
}

final class Clerk extends Employee{

   // @Override
    void raiseSalary() throws SQLException {
        salary = salary + 10000;
        connectionDB.update(salary);


    }

    Clerk() {
        designation = "Clerk";
        salary = 12000;
        count++;

    }
}

final class Programmer extends Employee{

    @Override
    void raiseSalary() throws SQLException {
        salary = salary + 10000;
        connectionDB.update(salary);
    }

    Programmer() {
        designation = "Programmer";
        salary = 28000;
        count++;
    }
}

public class Data {
    public static void main(String[] args) throws SQLException{
        int choice1 = 0;
        int choice2 = 0;

        ArrayList<Object> arr = new ArrayList();

        ConnectionDB connectionDB = new ConnectionDB("root","root");

        Scanner sc = new Scanner(System.in);
        Clerk c;
        while(choice1 != 4){
            System.out.print("1.Create\n2.Display\n3.Rise Salary\n4.Exit\nEnter your choice : ");
            choice1 = sc.nextInt();
            switch (choice1){
                case 1:
                    while(choice2 != 4){
                        System.out.print("1.Clerk\n2.Programmer\n3.Manager\n4.Exit\nEnter your choice : ");
                        choice2 = sc.nextInt();
                        switch (choice2){
                            case 1:
                                c = new Clerk();
                                arr.add(c);
                                c.connectionDB.insert(c.id,c.designation,c.age, c.name,c.salary);
                                break;
                            case 2:
                                Programmer p = new Programmer();
                                arr.add(p);
                                p.connectionDB.insert(p.id,p.designation,p.age, p.name,p.salary);
                                break;
                            case 3:
                                Manager m = new Manager();
                                arr.add(m);
                                m.connectionDB.insert(m.id,m.designation,m.age, m.name,m.salary);

                                break;
                            case 4:
                                System.out.println("Returning to main menu");
                                choice2 = 4;
                                break;
                            default:
                                System.out.println("Wrong choice, try again");
                        }
                    }
                    choice2 = 0;
                    break;
                case 2 :
                        connectionDB.display();

                    break;
                case 3:
                    System.out.println("Rising the salary");
                    Iterator ite = arr.iterator();
                    while(ite.hasNext()){
                        Employee et = (Employee) ite.next();
                        et.raiseSalary();
                    }


                    break;
                case 4:
                    choice1 = 4;
                    break;
                default:
                    System.out.println("Wrong choice, try again");


            }
        }
    }
}

