package com.Employee.info.usingJDBC;
import java.sql.*;
import java.util.Scanner;

abstract class Info1 {

	//public static void main(String[] args) {
		int id;
		String name;
		int age;
		int salary;
		String designation;
		static int count =0;
		
		Info1()
		{
			try {
				String url = "jdbc:mysql://localhost:3306/ed";
				//Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection conn = DriverManager.getConnection(url,"root","root");
				PreparedStatement statement = conn.prepareStatement("insert into emp values(?,?,?,?,?)");
				
				
				Scanner sc = new Scanner(System.in);
				
				
				System.out.println("\n Enter ID: ");
				statement.setInt(1,sc.nextInt());
				
				
				System.out.println("\n Enter Name: ");
				statement.setString(2,sc.next());
				
				System.out.println("\n Enter Age: ");
				statement.setInt(3,sc.nextInt());
				
				statement.setInt(4,salary);
				
				statement.setString(5, designation);
				statement.execute();
				System.out.println("Record Inserted Successfully .......");
				
			}catch (Exception e) {
				System.out.println(e);
			}
			
		}
		
		public static void display() {
			
			
			try
			{
				String url = "jdbc:mysql://localhost:3306/ed";
				//Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection conn = DriverManager.getConnection(url,"root","root");
				Statement statement = conn.createStatement();
				ResultSet rs = statement.executeQuery("select * from ed");
				while(rs.next())
				{
					System.out.println(rs.getInt(1) +"\t"+rs.getString(2)+"\t"+rs.getInt(3)+"\t"+rs.getInt(4)+"\t"+rs.getString(5));
					
				}
			}catch(Exception e) {
				System.out.println(e);
			}
		}
				
		public abstract void riseSalary();	
				
				
		//System.out.println("\nName:"+name+ "\nAge: "+age+ "\nDesignation:"+designation+ "\nSalary :" +salary);
		//}
		
		
}




final class Clerk extends Info1{
	public Clerk() {
		salary=10000;
		designation="Clerk";
	}
	public void riseSalary() {
		salary=salary+10000;
	}
}


final class Programmer extends Info1{
	public Programmer() {
		salary=10000;
		designation="Clerk";
	}
	public void riseSalary() {
		salary=salary+10000;
	}
}


final class Manager extends Info1{
	public Manager() {
		salary=10000;
		designation="Clerk";
	}
	public void riseSalary() {
		salary=salary+10000;
	}
}


public class Info{
	public static void main(String args[])
	{
		int ch1=0,ch2=0;
		do
		{
			System.out.println("************************************************");
			 System.out.println("1.Create\n2.Display\n3.Rise Salary\n4.Exit");
			 System.out.println("**********************************************");
			 System.out.println("Enter your choice:");
			 
			 Scanner sc1 = new Scanner(System.in);
			 ch1=sc1.nextInt();
			 
			 
			 if(ch1==1)
			 {
				 do
				 {
					 System.out.println("************************************************");
					 System.out.println("1.Clerk\n2.Manager\n3.Programmer\n4.Exit");
					 System.out.println("**********************************************");
					 System.out.println("Enter your choice:");
					 
					 Scanner sc2 = new Scanner(System.in);
					 ch2 = sc2.nextInt();
					 
					 switch(ch2) {
					 case 1:
						 Clerk c =new Clerk();
						 break;
						  case 2:
						 Manager m =new Manager();
						 break;
					 case 3:
						 Programmer p =new Programmer();
						 break;
						 
					 }
				 }
				 while(ch2!=4);
			 }
			 
			 if(ch1==2) {
				 Info1.display();
			 }
			 
			 if(ch1==3) {
				 try {
					 String url = "jdbc:mysql://localhost:3306/employees_database";
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection conn = DriverManager.getConnection(url,"root","root");
						Statement statement = conn.createStatement();
						
						statement.executeQuery("update emp set salary=salary+10000");
						
				 }catch(Exception e) {
					 System.out.println(e);
				 }
				 
			 }
			 
			 
		}
		
		
		while(ch1!=4);
		System.out.println("Total number of Employees created :"  +Info1.count);
	}
}
	



						
					 
					 
						 
						 
						 
						 
					 
					 
					 
					 
				 
			 
		






				
				
				
				
				
				
				
				
		
	


