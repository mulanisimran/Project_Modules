package com.simran.spring.basics;

public interface SortAlgorithm {
	public int[] sort(int[] numbers);
}
