

/*
 * * AACD => CD  CDAA => CDAA      ACDB => CDB
 */


public class StringHelper {

	//public static void main(String[] args) {
		
		public String truncateAInFirst2Positions(String str) {
			if(str.length() <= 2)
				return str.replaceAll("A", " ");
			
			String first2Chars = str.substring(0, 2);
			String stringMinusFirst2Chars = str.substring(2);
			
			
			return first2Chars.replaceAll("A", "") +stringMinusFirst2Chars;
			
		}

	}


