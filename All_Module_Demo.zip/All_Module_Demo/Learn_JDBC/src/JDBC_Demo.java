import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC_Demo {

	public static void main(String[] args) {
		
		
		//Establish Connection object---To connect Database
		String url ="jdbc:mysql://IPAddress:PortNumber/employees-database";
		try {
			Connection conn = DriverManager .getConnection(url,"username","password");
			
			
		//Create a statement object to send to the database
			Statement statement = conn.createStatement();
			
		
			//Execute the statement object
			//ResultSet resultSet = statement.executeQuery("select * from Employee");
			statement.executeQuery("insert into employee_tbl (id,name,dept,salary) "
					+"values(800,'Simran','sales' , 5500);");
			
			
			
//			int salaryTotal = 0;
//			//Process the result--
//			while(resultSet.next()) {
//				salaryTotal = salaryTotal + Integer.parseInt( resultSet.getInt("salary"));
//				System.out.println(salaryTotal);
//				
//				//System.out.println(resultSet.getString("name"));  //provide colum name "name"
//				//resultSet.getString("name");
//				
//				
//				
//			}
			
			
			
			
		} catch (SQLException e) {
						e.printStackTrace();
		}
		
		
	}

}

