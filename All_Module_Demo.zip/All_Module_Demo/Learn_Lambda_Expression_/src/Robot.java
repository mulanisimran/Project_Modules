
public class Robot implements Walkable {

	public void walk() {
		System.out.println("Robot Waliking");
	}
}
