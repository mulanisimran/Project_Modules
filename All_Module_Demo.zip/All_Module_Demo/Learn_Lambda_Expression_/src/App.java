//Lambda Expression With no Arguments

public class App {

	public static void main(String[] args) {
	
		
		//This is known as Polymorphism
		Human human = new Human();
		//Walker(human);
		//human.walk();
		
		Robot robot = new Robot();
		//Walker(robot);
		
		
		
		//In lambda,We just want their behavior
		//Lambda Expression---shorter version of anonymous class---this is a implementation for Walkable interface
		//Walker( () ->System.out.println("Custom Object Walking...."));
		//aBlockOfCode() ->System.out.println("Custom Object Walking...."));
		//It accepts Walkable --Convert Walkable interface into Functu
		Walker (() -> System.out.println("Custom Object Walking...."));
		//ALambdaInterface aBlockOfCode = () -> {
		Walkable aBlockOfCode = () -> {
		System.out.println("Custom Object Walking....");
		System.out.println("Custom Object Tripped");
		System.out.println("Custom Object Runnimg");
	};
	
	//Below line will give an error cause walker() method only accpts Walkable interface
	Walker(aBlockOfCode);
	
	
	// Lambda Expression for Hello There
	ALambdaInterface helloVar = ()-> System.out.println("Hello There");
	
	// Lambda Expression for Adding
	Calculate sumVar = (a , b) ->  a + b;
	helloVar.someMethod();  //not need printline statement because helloVar printing above
	System.out.println(sumVar.compute(4, 6));
	
	
	// Lambda Expression for Division
	Calculate nonZeroDivider = (a,b)-> {
		
		if(a == 0) {
			return 0;
		}
		return a/b;
	};
	System.out.println(nonZeroDivider.compute(42, 6));
	
																							
	// Lambda Expression for Reverse String datatype
	//MyGenericInterface StringWorker reverser =  (str) -> {
	//String result = "";
	//for(int i =str.length()-1 ;i>=0 ; i--) {
		//result = result + str.charAt(i);

//}
	//return result;
//};
//System.out.println(reverser.work("Vehicle"));
	
	
	
	
	StringWorker reverser =  (str) -> {
		String result = "";
		for(int i =str.length()-1 ;i>=0 ; i--) {
			result = result + str.charAt(i);

	}
		return result;
	};
	System.out.println(reverser.work("Vehicle"));
	
	
	
	
	// Lambda Expression for Factorial
	NumberWorker computedNumber =(num) -> {
		int result = 1;
		for ( int i=1 ; i <= num ; i++) {
			result = i*result ;
		}
		return result;
	};
	
	System.out.println(computedNumber.compute(5));
	
	
	
	
}
	
	
	
	
	
	
	//Method Hello There
	public void sayHello() {
		System.out.println("Hello There");
	}																							
		
	//Method Sum
	public int sum(int arg1 , int arg2)	{
		return arg1+arg2;
	}
	
	// MEthod Division
	public int nonZeroDivide(int arg1 ,int arg2) {
		if(arg1 == 0) {
			return 0;
		}
		return arg1/arg2;
	}
	
	//Method Reverse String
	public String reverse(String str) {
		String result = "";
		for(int i =str.length()-1 ;i>=0 ; i--) {
			result = result + str.charAt(i);
			
		}
		return result;
		
	}
		
	//Method Factorial
	public int factorial(int num) {
		int result = 1;
		for ( int i=1 ; i <= num ; i++) {
			result = i*result ;
		}
		return result;
	}
																												
	
	public static void Walker(Walkable walkableEntity ) {
		walkableEntity.walk();
		
		
	}

}

//Interface fo Adding and Division
interface Calculate{
	public int compute(int a ,int b);
		
	
}

//Interface for Reverse String
interface StringWorker{
	public String work(String str);
}


//We can make Reverse and Factorial interface as Generic also
//interface MyGenericInterface<T>{
	//public  T work(T t);
//Lambda Expression
	



//Interface for Factorial
interface NumberWorker{
	public int compute(int a);
}







//We dot need main method and all--We just want their behaviour i.e.System.out.println("");
//No walk() method needed


//Walker(new Walkable() {
//@Override
//public void walk() {

	//}

					//});