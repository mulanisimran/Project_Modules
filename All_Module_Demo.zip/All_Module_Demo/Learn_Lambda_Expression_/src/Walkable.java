

@FunctionalInterface
public interface Walkable {
	public void walk();
	//public void run(); //It gives error--not functional interface beacause it has more than one abstract method defined
	//Functional Interface contains only one method
}
