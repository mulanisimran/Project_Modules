
public interface ALambdaInterface{
	public void someMethod() ; //We dont give body here cause it is a function
		
	
}
