package streams.practical;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Stream;

public class StockDataCsv_Stream {

	public static void main(String[] args) throws IOException {
		
		Stream<String> rows = Files.lines(Paths.get("files/stockDataCsv.txt"));
		int rowCount = (int) rows
				.map(x -> x.split(" , "))
				.filter(x -> x.length > 3)
				.count();
				
				System.out.println( rowCount + "Good Rows:");
				rows.close();

	}

}
