package streams.practical;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

public class ContainSpecificWord_Stream {

	public static void main(String[] args) throws IOException {
		
		List<String> words = Files.lines(Paths.get("files/wordFile.txt"))
		.filter( x -> x.contains("th"))
		.collect(Collectors.toList());
		
		words.forEach(x -> System.out.print(x + "  ,  "));
		System.out.println();
		

	}

}
