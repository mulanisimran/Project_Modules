package streams.practical;
import java.util.stream.IntStream;

public class Skip_Stream {
		public static void main(String[] args) {
		
				//Integer stream with skip
				IntStream
				
				.range(1, 10) //It prints 1-9
				.skip(5) //skip 5 elements of the stream 
				.forEach( (x) -> System.out.print(x));
			
				System.out.println();
				
	}	

	}




