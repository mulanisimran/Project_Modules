package streams.practical;

import java.util.Arrays;

public class SquareAvarage_Stream {

	public static void main(String[] args) {
		
		//Average of squares of an int array
		Arrays.stream(new int[] {2,4,6,8,10})
		.map((x) -> x * x)
		.average()
		.ifPresent(n -> System.out.println(n));
		System.out.println();
		
		

	}

}
