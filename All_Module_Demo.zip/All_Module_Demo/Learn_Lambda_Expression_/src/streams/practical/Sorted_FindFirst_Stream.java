package streams.practical;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Sorted_FindFirst_Stream {
	public static void main(String[] args) {

	
	Stream.of("Hello","Bottle","Africa")
	.sorted()
	.findFirst()
	.ifPresent((x) -> System.out.println(x));
}
}
