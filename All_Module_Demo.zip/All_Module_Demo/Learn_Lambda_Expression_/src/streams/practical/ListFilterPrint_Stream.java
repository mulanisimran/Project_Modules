package streams.practical;

import java.util.Arrays;
import java.util.List;

public class ListFilterPrint_Stream {

	public static void main(String[] args) {
		
		//Stream from a list,filter and print
		List<String> listOfitems =  Arrays.asList( "cat","Car", "Computer", "Toothpaste", "Box", "pencil", "door","toy");
		listOfitems.stream()
		.map(x -> x.toLowerCase())
		.filter(x -> x.startsWith("c"))
		.sorted()
		.forEach( x -> System.out.print(x + ","));

	}

}
