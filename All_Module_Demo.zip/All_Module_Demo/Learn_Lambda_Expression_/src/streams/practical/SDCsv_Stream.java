package streams.practical;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class SDCsv_Stream {

	public static void main(String[] args) throws IOException {
		
		
		Stream<String> rows = Files.lines(Paths.get("files/stockDataCsv.txt"));
		rows.map ( x -> x.split( "  ,   "))
		.filter( x -> x.length > 3)
		.filter(x -> Integer.parseInt(x[1] .trim())  > 15)
		.forEach(x -> System.out.print(x[0] .trim() + "" +x[2].trim() + "" +x[3].trim()));
		rows.close();

	}

}
