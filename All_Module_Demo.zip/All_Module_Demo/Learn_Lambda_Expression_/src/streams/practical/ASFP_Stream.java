package streams.practical;

import java.util.stream.Stream;

public class ASFP_Stream {

	public static void main(String[] args) {
		
		
		//Stream from Array , sort , filter and print
		String[] items = {"car", "computer", "toothpaste", "box", "pencil", "door","toy"};
		Stream.of(items)
		//It will print items starts with "t"
		.filter((x)   -> x.startsWith("t"))   
		.sorted()
		.forEach( x -> System.out.println(x + ","));
		System.out.println();
	}

}
