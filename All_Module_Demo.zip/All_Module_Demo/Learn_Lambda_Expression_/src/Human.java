
public class Human implements Walkable{

	public void walk() {
		System.out.println("Human Waliking");
}
}
