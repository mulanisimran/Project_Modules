package com.simran.restful.webservices.restfulcoursemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulCourseManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulCourseManagementApplication.class, args);
	}

}
